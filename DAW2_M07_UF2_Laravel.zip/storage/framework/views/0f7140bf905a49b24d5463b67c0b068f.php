

<h1><?php echo e($title); ?></h1>

<?php if(empty($films)): ?>
    <p style="color: red;">No se ha encontrado ninguna película.</p>
<?php else: ?>
    <div align="center">
        <table border="1">
            <thead>
                <tr>
                    <!-- Verifica si el array films no está vacío y es un array -->
                    <?php if(!empty($films) && is_array($films) && count($films) > 0): ?>
                        <!-- Obtiene las claves del primer elemento del array -->
                        <?php $__currentLoopData = array_keys(reset($films)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e(ucfirst($key)); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php $__currentLoopData = $film; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Verifica si la clave es 'img_url' para mostrar la imagen -->
                            <?php if($key === 'img_url'): ?>
                                <td><img src="<?php echo e($value); ?>" style="width: 100px; height: 120px;" alt="Imagen de película"></td>
                            <?php else: ?>
                                <td><?php echo e($value); ?></td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\M07\DAW2_M07_UF2_Laravel\resources\views/films/list.blade.php ENDPATH**/ ?>